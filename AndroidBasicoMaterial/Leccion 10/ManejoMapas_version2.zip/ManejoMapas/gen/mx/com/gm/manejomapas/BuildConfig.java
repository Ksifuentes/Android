/** Automatically generated file. DO NOT MODIFY */
package mx.com.gm.manejomapas;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}